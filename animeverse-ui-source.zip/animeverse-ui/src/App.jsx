import { useEffect, useMemo, useState } from 'react'
import { Routes, Route, useLocation, useNavigate } from 'react-router-dom'
import { Menu, Search } from 'lucide-react'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import AnimeModal from './components/AnimeModal'
import Home from './pages/Home'
import Discover from './pages/Discover'
import Watchlist from './pages/Watchlist'
import Schedule from './pages/Schedule'
import { animeSeed } from './data/anime'
import { fetchTopAnime, searchAnime } from './services/animeApi'

export default function App() {
  const [anime, setAnime] = useState(animeSeed)
  const [loading, setLoading] = useState(false)
  const [savedIds, setSavedIds] = useState(() => JSON.parse(localStorage.getItem('animeverse-watchlist') || '[]'))
  const [selected, setSelected] = useState(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [activeQuery, setActiveQuery] = useState('')
  const location = useLocation()
  const navigate = useNavigate()

  useEffect(() => { localStorage.setItem('animeverse-watchlist', JSON.stringify(savedIds)) }, [savedIds])
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'smooth' }) }, [location.pathname])
  useEffect(() => {
    let alive = true
    setLoading(true)
    fetchTopAnime().then(data => { if (alive && data.length) setAnime(data) }).catch(() => {}).finally(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [])

  const toggleSaved = (item) => setSavedIds(ids => ids.includes(item.mal_id) ? ids.filter(id => id !== item.mal_id) : [...ids, item.mal_id])
  const runSearch = async () => {
    const term = query.trim()
    setActiveQuery(term)
    if (!term) { navigate('/discover'); return }
    setLoading(true)
    try { const results = await searchAnime(term); setAnime(results) } catch { /* Keep current data if API is unavailable. */ }
    finally { setLoading(false); navigate('/discover') }
  }

  const pageTitle = useMemo(() => ({
    '/': 'Discover your next anime world',
    '/discover': 'Discover anime',
    '/watchlist': 'My watchlist',
    '/schedule': 'Release schedule'
  }[location.pathname] || 'AnimeVerse'), [location.pathname])

  return <div className="app-shell">
    <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)}/>
    <main className="main-area">
      <Topbar onMenu={() => setSidebarOpen(true)} query={query} setQuery={setQuery} onSearch={runSearch}/>
      <Routes>
        <Route path="/" element={<Home anime={anime} savedIds={savedIds} onToggle={toggleSaved} onOpen={setSelected} loading={loading}/>}/>
        <Route path="/discover" element={<Discover anime={anime} savedIds={savedIds} onToggle={toggleSaved} onOpen={setSelected} query={activeQuery} loading={loading}/>}/>
        <Route path="/watchlist" element={<Watchlist anime={anime} savedIds={savedIds} onToggle={toggleSaved} onOpen={setSelected}/>}/>
        <Route path="/schedule" element={<Schedule/>}/>
        <Route path="*" element={<div className="page"><div className="empty-state"><h3>Page not found</h3><p>The page you’re looking for doesn’t exist.</p><button className="primary-btn" onClick={()=>navigate('/')}>Back home</button></div></div>}/>
      </Routes>
      <footer className="footer"><div className="brand small-brand"><div className="brand-mark">A</div><span>anime<span className="brand-accent">verse</span></span></div><span>Made for the love of anime.</span><span>© 2026 AnimeVerse UI</span></footer>
    </main>
    <AnimeModal anime={selected} saved={selected ? savedIds.includes(selected.mal_id) : false} onClose={()=>setSelected(null)} onToggle={toggleSaved}/>
  </div>
}
