import { NavLink } from 'react-router-dom'
import { Compass, House, Clapperboard, CalendarDays, Bookmark, Sparkles, Heart, Settings, ChevronLeft } from 'lucide-react'

const links = [
  { to: '/', label: 'Home', icon: House },
  { to: '/discover', label: 'Discover', icon: Compass },
  { to: '/seasonal', label: 'Seasonal anime', icon: Clapperboard },
  { to: '/schedule', label: 'Release schedule', icon: CalendarDays },
  { to: '/watchlist', label: 'My watchlist', icon: Bookmark },
]
export default function Sidebar({ open, onClose }) {
  return <>
    <div className={`mobile-scrim ${open ? 'show' : ''}`} onClick={onClose}/>
    <aside className={`sidebar ${open ? 'open' : ''}`}>
      <div className="brand"><div className="brand-mark">A</div><span>anime<span className="brand-accent">verse</span></span></div>
      <div className="side-label">MENU</div>
      <nav>{links.map(({to,label,icon:Icon}) => <NavLink key={to} to={to} end={to === '/'} onClick={onClose}><Icon size={18}/><span>{label}</span>{label === 'My watchlist' && <span className="nav-dot"/>}</NavLink>)}</nav>
      <div className="side-label explore-label">EXPLORE</div>
      <nav>
        <NavLink to="/discover?genre=Action" onClick={onClose}><Sparkles size={18}/><span>Popular genres</span></NavLink>
        <NavLink to="/discover?genre=Romance" onClick={onClose}><Heart size={18}/><span>For your mood</span></NavLink>
      </nav>
      <div className="sidebar-bottom"><div className="upgrade-card"><div className="upgrade-icon"><Sparkles size={17}/></div><b>Your anime corner</b><p>Keep track of every story you love.</p><NavLink to="/watchlist">Open my list <span>↗</span></NavLink></div><div className="side-footer"><span>ANIMEVERSE UI</span><Settings size={15}/></div></div>
    </aside>
  </>
}
