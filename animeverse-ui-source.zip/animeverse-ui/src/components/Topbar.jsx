import { Search, Bell, Menu, Command } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
export default function Topbar({ onMenu, query, setQuery, onSearch }) {
  const navigate = useNavigate()
  return <header className="topbar">
    <button className="icon-btn mobile-menu" onClick={onMenu}><Menu/></button>
    <form className="top-search" onSubmit={e => {e.preventDefault(); onSearch(); navigate('/discover')}}>
      <Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search anime, characters, genres..." /><kbd><Command size={11}/> K</kbd>
    </form>
    <div className="top-actions"><button className="icon-btn notification" aria-label="Notifications"><Bell size={18}/><i/></button><button className="profile" aria-label="Profile">A</button></div>
  </header>
}
