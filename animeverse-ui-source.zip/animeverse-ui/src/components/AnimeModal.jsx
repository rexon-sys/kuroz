import { X, Star, Bookmark, Play, CalendarDays } from 'lucide-react'

export default function AnimeModal({ anime, saved, onClose, onToggle }) {
  if (!anime) return null
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <section className="anime-modal" onClick={e => e.stopPropagation()}>
        <button className="modal-close icon-btn" onClick={onClose}><X /></button>
        <div className="modal-hero" style={{ backgroundImage: `linear-gradient(90deg,#11111b 0%,rgba(17,17,27,.78) 58%,rgba(17,17,27,.25)),url(${anime.image})` }}>
          <div className="modal-copy">
            <span className="eyebrow">ANIME DETAILS</span>
            <h2>{anime.title_english || anime.title}</h2>
            <div className="detail-line"><span><Star size={14} fill="currentColor"/> {anime.score || 'N/A'}</span><span><CalendarDays size={14}/> {anime.year || 'TBA'}</span><span>{anime.episodes || '?'} episodes</span></div>
            <p>{anime.synopsis || 'Synopsis is not available yet.'}</p>
            <div className="tag-row">{anime.genres?.slice(0,4).map(g => <span className="tag" key={g}>{g}</span>)}</div>
            <div className="modal-actions">
              <button className="primary-btn" onClick={() => onToggle(anime)}><Bookmark size={16}/> {saved ? 'Saved to list' : 'Add to watchlist'}</button>
              <button className="secondary-btn" onClick={onClose}><Play size={16}/> Explore more</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
