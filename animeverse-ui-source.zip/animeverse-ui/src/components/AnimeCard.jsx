import { Bookmark, Star, Play } from 'lucide-react'

export default function AnimeCard({ anime, saved, onToggle, onOpen, compact = false }) {
  return (
    <article className={`anime-card ${compact ? 'compact' : ''}`} onClick={() => onOpen(anime)}>
      <div className="poster-wrap">
        <img src={anime.image} alt={anime.title} loading="lazy" onError={e => { e.currentTarget.src = 'https://placehold.co/500x700/171722/f4f0ff?text=Anime' }} />
        <div className="poster-shade" />
        <span className="score"><Star size={13} fill="currentColor" /> {anime.score || '—'}</span>
        <button className={`save-btn ${saved ? 'active' : ''}`} aria-label="Toggle watchlist" onClick={e => { e.stopPropagation(); onToggle(anime) }}>
          <Bookmark size={17} fill={saved ? 'currentColor' : 'none'} />
        </button>
        <button className="quick-play" aria-label="View anime"><Play size={17} fill="currentColor" /></button>
      </div>
      <div className="card-meta">
        <h3>{anime.title_english || anime.title}</h3>
        <p>{anime.year || 'Anime'} <span>•</span> {anime.episodes ? `${anime.episodes} eps` : 'TBA'}</p>
      </div>
    </article>
  )
}
