const API = 'https://api.jikan.moe/v4'

export async function fetchTopAnime() {
  const response = await fetch(`${API}/top/anime?limit=12`)
  if (!response.ok) throw new Error('Could not load anime')
  const json = await response.json()
  return json.data.map(item => ({
    mal_id: item.mal_id,
    title: item.title,
    title_english: item.title_english,
    score: item.score,
    episodes: item.episodes,
    year: item.year || item.aired?.prop?.from?.year,
    status: item.status,
    genres: item.genres?.map(g => g.name) || [],
    synopsis: item.synopsis,
    image: item.images?.jpg?.large_image_url
  }))
}

export async function searchAnime(query) {
  const response = await fetch(`${API}/anime?q=${encodeURIComponent(query)}&limit=18`)
  if (!response.ok) throw new Error('Search failed')
  const json = await response.json()
  return json.data.map(item => ({
    mal_id: item.mal_id, title: item.title, title_english: item.title_english,
    score: item.score, episodes: item.episodes, year: item.year,
    status: item.status, genres: item.genres?.map(g => g.name) || [],
    synopsis: item.synopsis, image: item.images?.jpg?.large_image_url
  }))
}
