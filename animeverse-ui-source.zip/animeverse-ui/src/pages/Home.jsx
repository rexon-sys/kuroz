import { ArrowUpRight, Play, Sparkles, TrendingUp, ChevronRight } from 'lucide-react'
import AnimeCard from '../components/AnimeCard'
import { Link } from 'react-router-dom'

export default function Home({ anime, savedIds, onToggle, onOpen, loading }) {
  const featured = anime[0]
  return <div className="page home-page">
    <section className="hero">
      <div className="hero-glow"/><div className="hero-grid"/>
      <div className="hero-content">
        <span className="hero-kicker"><span className="pulse"/> YOUR NEXT OBSESSION STARTS HERE</span>
        <h1>Find your next<br/><em>anime world.</em></h1>
        <p>From timeless classics to hidden gems — discover stories that stay with you.</p>
        <div className="hero-buttons"><Link to="/discover" className="primary-btn"><Play size={16} fill="currentColor"/> Explore anime</Link><Link to="/watchlist" className="ghost-btn">My watchlist <ArrowUpRight size={16}/></Link></div>
      </div>
      <div className="hero-art">
        <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
        <div className="hero-poster poster-back"><img src={anime[3]?.image || anime[1]?.image} alt="Anime artwork"/></div>
        <div className="hero-poster poster-front"><img src={featured?.image} alt={featured?.title}/></div>
        <div className="floating-note note-top"><Sparkles size={14}/> Curated for you</div>
        <div className="floating-note note-bottom"><span className="note-score">★ 9.3</span><span>Top rated picks</span></div>
      </div>
      <div className="hero-index"><span>01</span><i/> DISCOVER SOMETHING NEW</div>
    </section>

    <section className="section-block">
      <div className="section-heading"><div><span className="eyebrow"><TrendingUp size={13}/> THE COMMUNITY IS WATCHING</span><h2>Trending <em>right now</em></h2><p>Popular picks making waves this week.</p></div><Link to="/discover" className="text-link">View all <ChevronRight size={16}/></Link></div>
      {loading ? <div className="loading-grid">{Array.from({length:6}).map((_,i)=><div className="skeleton" key={i}/>)}</div> : <div className="anime-grid">{anime.slice(0,6).map(a=><AnimeCard key={a.mal_id} anime={a} saved={savedIds.includes(a.mal_id)} onToggle={onToggle} onOpen={onOpen}/>)}</div>}
    </section>

    <section className="feature-strip"><div className="feature-icon"><Sparkles/></div><div><span className="eyebrow">A LITTLE INSPIRATION</span><h2>Not sure what to watch?</h2><p>Browse by genre and let your next favourite find you.</p></div><Link to="/discover" className="round-arrow"><ArrowUpRight/></Link></section>
    <section className="section-block"><div className="section-heading"><div><span className="eyebrow">MORE TO EXPLORE</span><h2>Stories worth <em>your time</em></h2></div><Link to="/discover" className="text-link">Discover more <ChevronRight size={16}/></Link></div><div className="anime-grid">{anime.slice(6,12).map(a=><AnimeCard key={a.mal_id} anime={a} saved={savedIds.includes(a.mal_id)} onToggle={onToggle} onOpen={onOpen}/>)}</div></section>
  </div>
}
