import { useMemo, useState } from 'react'
import { SlidersHorizontal, SearchX } from 'lucide-react'
import AnimeCard from '../components/AnimeCard'
import { genres } from '../data/anime'

export default function Discover({ anime, savedIds, onToggle, onOpen, query, loading }) {
  const [genre, setGenre] = useState('All')
  const [sort, setSort] = useState('top')
  const filtered = useMemo(() => {
    let list = anime.filter(a => genre === 'All' || a.genres?.some(g => g.toLowerCase() === genre.toLowerCase()))
    if (sort === 'az') list = [...list].sort((a,b) => a.title.localeCompare(b.title))
    if (sort === 'year') list = [...list].sort((a,b) => (b.year || 0) - (a.year || 0))
    if (sort === 'top') list = [...list].sort((a,b) => (b.score || 0) - (a.score || 0))
    return list
  }, [anime, genre, sort])
  return <div className="page">
    <div className="page-title"><span className="eyebrow">THE ANIME LIBRARY</span><h1>Discover <em>anime.</em></h1><p>Find a new favourite, revisit a classic, or follow a story you love.</p></div>
    <div className="filter-bar"><div className="genre-pills">{genres.map(g=><button key={g} className={genre===g?'selected':''} onClick={()=>setGenre(g)}>{g}</button>)}</div><label className="sort-select"><SlidersHorizontal size={15}/><select value={sort} onChange={e=>setSort(e.target.value)}><option value="top">Top rated</option><option value="year">Newest</option><option value="az">A to Z</option></select></label></div>
    {query && <p className="result-label">Showing results for <b>“{query}”</b></p>}
    {loading ? <div className="loading-grid">{Array.from({length:8}).map((_,i)=><div className="skeleton" key={i}/>)}</div> : filtered.length ? <div className="anime-grid discover-grid">{filtered.map(a=><AnimeCard key={a.mal_id} anime={a} saved={savedIds.includes(a.mal_id)} onToggle={onToggle} onOpen={onOpen}/>)}</div> : <div className="empty-state"><SearchX size={32}/><h3>No anime found</h3><p>Try another genre or search term.</p></div>}
  </div>
}
