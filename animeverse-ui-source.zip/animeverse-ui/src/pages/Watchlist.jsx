import { Bookmark, ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import AnimeCard from '../components/AnimeCard'
export default function Watchlist({ anime, savedIds, onToggle, onOpen }) {
  const saved = anime.filter(a => savedIds.includes(a.mal_id))
  return <div className="page"><div className="page-title"><span className="eyebrow"><Bookmark size={13}/> YOUR PERSONAL COLLECTION</span><h1>My <em>watchlist.</em></h1><p>Your saved stories, all in one place.</p></div>
    {saved.length ? <><div className="list-summary"><b>{saved.length} titles saved</b><span>Keep building your anime queue.</span></div><div className="anime-grid discover-grid">{saved.map(a=><AnimeCard key={a.mal_id} anime={a} saved onToggle={onToggle} onOpen={onOpen}/>)}</div></> : <div className="empty-state"><Bookmark size={34}/><h3>Your list is waiting</h3><p>Save anime you want to watch and they’ll show up here.</p><Link className="primary-btn" to="/discover">Explore anime <ArrowRight size={16}/></Link></div>}
  </div>
}
