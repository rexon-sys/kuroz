# AnimeVerse UI

A responsive anime discovery website UI built with React, Vite, React Router and plain CSS.

## Features
- Responsive dark anime discovery dashboard
- Home, Discover, Watchlist and Release Schedule pages
- Search anime using the Jikan public API (no API key required)
- Load top anime from Jikan API with local fallback data
- Genre filtering and sorting
- Anime detail modal
- Save/remove titles in a browser-local watchlist using localStorage
- Mobile navigation and responsive layouts

## Run locally
1. Install Node.js (LTS).
2. Extract this folder and open it in VS Code.
3. Open a terminal in this folder.
4. Run:

```bash
npm install
npm run dev
```

5. Open the localhost URL shown by Vite.

## Build for production
```bash
npm run build
npm run preview
```

## Data/API notes
The project uses the public Jikan API, an unofficial MyAnimeList data API:
- `https://api.jikan.moe/v4/top/anime`
- `https://api.jikan.moe/v4/anime?q=...`

API availability and rate limits are controlled by that service. The app falls back to local sample data if the API is unavailable. Some sample art is illustrative placeholder artwork, not official anime key art.

## Important
This is a discovery/watchlist UI. It does not host or stream anime episodes. Add only licensed viewing links if you later add a watch-provider feature.
