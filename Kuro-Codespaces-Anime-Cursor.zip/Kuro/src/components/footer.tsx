import React from "react";
import Image from "next/image";
import Link from "next/link";

const Footer = () => {
  return (
    <footer className="kuro-footer mt-20 border-t border-white/10 px-6 py-12">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-5 text-center">
        <Link href="/" className="flex items-center gap-3">
          <Image src="/kuro-mark.svg" alt="Kuro" width={42} height={42} />
          <span className="text-lg font-black tracking-[0.32em] text-white">KURO</span>
        </Link>
        <p className="max-w-xl text-sm leading-6 text-white/45">
          Your next anime obsession starts here. Discover stories, explore worlds,
          and continue watching in one cinematic space.
        </p>
        <div className="h-px w-full max-w-3xl bg-gradient-to-r from-transparent via-white/15 to-transparent" />
        <p className="text-[11px] uppercase tracking-[0.22em] text-white/30">
          © {new Date().getFullYear()} KURO · Made for anime fans
        </p>
      </div>
    </footer>
  );
};

export default Footer;
